import psycopg2

try:
    # пытаемся подключиться к базе данных
    conn = psycopg2.connect(dbname='testdb', user='moneta', password='superpassword', host='localhost', port='5432')
except:
    # в случае сбоя подключения будет выведено сообщение
    print('Can`t establish connection to database')

cursor = conn.cursor()

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import sessionmaker

# Создаем движок для соединения с базой данных
engine = create_engine("postgresql://moneta:superpassword@localhost/testdb")

# Создаем базовый класс для наших моделей
Base = declarative_base()


# Определяем класс Customer, который соответствует таблице customers в базе данных
class Customer(Base):
    __tablename__ = "customers"

    id = Column(Integer, primary_key=True)
    name = Column(String)
    email = Column(String)
    address = Column(String)

    def __repr__(self):
        return f"<Customer(id={self.id}, name={self.name}, email={self.email}, address={self.address})>"

# Создаем таблицу customers в базе данных, если она еще не существует
Base.metadata.create_all(engine)

# Создаем фабрику сессий для работы с объектами Customer
Session = sessionmaker(bind=engine)

# Создаем сессию для выполнения операций с данными
session = Session()

# Добавляем нового клиента в базу данных
new_customer = Customer(name="Genry", email="genry@example.com", address="11111 Main Street")
session.add(new_customer)
session.commit()

# Получаем список всех клиентов из базы данных
customers = session.query(Customer).all()
print(customers)

# Получаем клиента по id из базы данных
customer = session.query(Customer).get(2)
print(customer)

# Изменяем имя клиента в базе данных
customer.name = "Bob"
session.commit()

# Удаляем клиента из базы данных
session.delete(customer)
session.commit()

# Закрываем сессию
session.close()