import streamlit as st
import pandas as pd
df = pd.DataFrame(
    {
        "Name": [],
        "Password": []
    }
)
reg=st.button('Регистрация')
log=st.button('Авторизация')
if reg:
    name = st.text_input('Login')
    password1 = st.text_input('Password')
    password2 = st.text_input('Repeat your password')
    err = 0
    if st.button('Отправить') :
        if password1 != password2:
            st.subheader('Пароли не совпадают')
            err=1

        if name == '':
            st.subheader('Введите логин')
            err=1

        if password1 == '' or password2 == '':
            st.subheader('Введите пароль/Повторите пароль')
            err = 1

if log:
    login = st.text_input('Login')
    pw = st.text_input('Password')
    if st.button('Отправить') :
        if login == '':
            st.subheader('Введите логин')
            err=1

        if pw == '':
            st.subheader('Введите пароль/Повторите пароль')
            err = 1

